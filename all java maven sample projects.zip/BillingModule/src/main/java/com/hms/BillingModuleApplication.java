package com.hms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication //@config //@enableautoconfig //@compScan
public class BillingModuleApplication {

	public static void main(String[] args) {
		SpringApplication.run(BillingModuleApplication.class, args);
	}

}

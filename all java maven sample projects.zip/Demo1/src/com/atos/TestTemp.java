package com.atos;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
class Emp2{}
public class TestTemp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Temp<String> t=new Temp<>();
		String h=t.display("67");
		System.out.println(h);
		t.a="hi";
		System.out.println(t.a);
		
		Temp<Integer> t1=new Temp<>();
		int h1=t1.display(78);
		System.out.println(h1);
		t1.a=45;
		System.out.println(t1.a);
		
		List<Integer> v=new ArrayList(20);
		v.add(89);
	//	v.add("hi");
		///in java 6
		List<Emp2> n1=new LinkedList<Emp2>();
		
		//in j7
		List<Emp2> n2=new LinkedList();
		List<Emp2> n3=new LinkedList<>();// from j7
		
		
	}

}

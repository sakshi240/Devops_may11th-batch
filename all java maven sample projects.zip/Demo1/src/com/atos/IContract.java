package com.atos;

public interface IContract {

	public static final int NO_OF_DAYS=31;
	
	public abstract void trainingJava();
	public abstract void trainingJspServ();
	
}

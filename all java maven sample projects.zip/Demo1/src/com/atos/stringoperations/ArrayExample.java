package com.atos.stringoperations;

public class ArrayExample {

	public static void main(String[] args) {
		float a[]=new float[1000];
		a[0]=1;
		a[1]=90;
			a=new float[2000];
		System.out.println(a[1]);	
	
		
	}

}

package com.atos;

import java.util.LinkedHashSet;
import java.util.Set;

public class TreeSetEx {

	public static void main(String[] args) {

			Set s=new LinkedHashSet<>();
			s.add(1);
			s.add(1);
			s.add('c');
			s.add(145);
			s.add(1.4d);
			s.add("hi");
			s.add(null);s.add(null);
			System.out.println(s);
			
			
	}

}

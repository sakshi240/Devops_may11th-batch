package com.atos;

import java.util.*;

public class ListDemo2 {

	public static void main(String[] args) {

		List l=null;
		//l=new ArrayList(); //upward casting
		l=new LinkedList();
		l.add(10); 
		l.add(new Integer(90));
		l.add(null);
		l.add(null);
		l.add(10);
		l.add("hello");
		System.out.println(l);
		
		System.out.println("can we add emp or admin obj into the list?");
		l.add(new Employee());//anonymous obj since doent hv names
		l.add(new Employee(1001,"ajay"));
		l.add(new Admin());
		l.add(new Admin(111,"admin1"));
		System.out.println(l);
		
		//iterator - pipe
		//listIterator
		//collection
		
		ListIterator i1=l.listIterator();
		
		while(i1.hasNext()){
			System.out.println(i1.nextIndex());
			System.out.println(i1.next());
			
		}
		
		
		
		//problem in these type of collection is iteration
		/*int a[]={1,2,3,4,5};
		for(int g:a)
			System.out.println(g);
		
		for(Object o:l){
			if(o instanceof Integer){
				Integer i1=(Integer)o;
				System.out.println(i1);
			}
			else if(o instanceof String)
				System.out.println((String)o);
			else if(o instanceof Employee){
				Employee emp1=(Employee)o;
				System.out.println(emp1);
			}
			else{
				Admin ad1=(Admin)o;
				System.out.println(ad1);
			}
		}*/
		
	}

}

class Employee
{
	private int empId;
	private String empName;
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public Employee() {
		// TODO Auto-generated constructor stub
	}
	public Employee(int empId, String empName) {
		super();
		this.empId = empId;
		this.empName = empName;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + "]";
	}
	
	
}
class Admin{
	private int adId;
	private String adName;
	
	public Admin() {
		// TODO Auto-generated constructor stub
	}
	
	public int getAdId() {
		return adId;
	}

	public void setAdId(int adId) {
		this.adId = adId;
	}

	public String getAdName() {
		return adName;
	}

	public void setAdName(String adName) {
		this.adName = adName;
	}

	public Admin(int adId, String adName) {
		super();
		this.adId = adId;
		this.adName = adName;
	}

	@Override
	public String toString() {
		return "Admin [adId=" + adId + ", adName=" + adName + "]";
	}
	
	
}

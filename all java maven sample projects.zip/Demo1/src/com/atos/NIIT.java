package com.atos;

public class NIIT implements IContractSpring{

	int bal=0;
	
	@Override
	public void trainingJava() {
		bal=IContract.NO_OF_DAYS-15;
		System.out.println("SLT -online - training done Bal days "+bal);
		
	}

	@Override
	public void trainingJspServ() {
		bal=bal-15;
		System.out.println("SLT -online bal days: "+bal);
	}

	@Override
	public void trainingSpring() {
		System.out.println("spring 8 days training");
		
	}

	@Override
	public void trainingSpringBoot() {
		System.out.println("spring boot 7 days training");
		
	}

}

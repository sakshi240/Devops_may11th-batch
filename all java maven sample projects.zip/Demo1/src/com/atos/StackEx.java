package com.atos;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Stack;

public class StackEx {

	public static void main(String[] args) {

		Stack st = new Stack();
		st.push("23");
		st.push(23);
		st.push("hello");
		st.push('c');
		System.out.println(st);
		System.out.println(st.peek());
		System.out.println(st.peek());
		System.out.println(st.pop()); //c and deletes from stack
		System.out.println(st.pop());//gets hello and then del
		System.out.println(st);
		
		st.add(123);
		st.add(1);
		st.add(10);
		st.add(1);
		System.out.println(st);
		System.out.println(st.peek());
		
		
		Deque stk=new ArrayDeque<>();

		stk.add("hi"); //acts like queue - FIFO
		stk.add("hello");
		stk.add("welcome");
		System.out.println(stk);
		System.out.println(stk.peek());
		
		stk.push("data1");//stack LIFO
		stk.push("data2");
		stk.push("data3");
		System.out.println(stk.peek());
	}

}

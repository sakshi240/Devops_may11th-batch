package com.atos;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ListOperations {

	public static void main(String[] args) {

		List l1=new ArrayList<>();
		l1.add(1);
		l1.add(11);
		l1.add(13);
		l1.add(1);
		l1.add(9);
		System.out.println("before sort : "+l1);
		List l2=new ArrayList<>();
		l2.add(100);
		l2.add(110);
		l2.add(130);
		l2.add(51);
		l2.add(29);
		
		Collections.sort(l1);
		
		System.out.println(l1);
		l1.add(l2);
		System.out.println("after adding l2 to l1 : "+l1);
		System.out.println(l1.get(5));
		System.out.println(((List)l1.get(5)).get(2));
		
		Collections.reverse(l1);
		System.out.println(l1);
		
	}

}

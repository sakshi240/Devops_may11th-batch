package com.atos;



public interface IContractSpring extends IContract{
//tra java();, trajsp();
	
	public void trainingSpring();
	public void trainingSpringBoot();
	
}

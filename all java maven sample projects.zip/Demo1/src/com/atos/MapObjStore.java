package com.atos;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class MapObjStore {
	static Scanner scan=null;
	static Map<Integer,Product> prodMap=null;
	
	
	static{
		prodMap=new HashMap<>();
		prodMap.put(1001,new Product(1001,"Ac",23434.f));
		prodMap.put(1002,new Product(1002,"TV",2344.f));
		prodMap.put(1003,new Product(1003,"Dvd",3234.f));
		//prodMap.put("ddd", "wrong");
	}
	
	public static void main(String[] args) {
		
		System.out.println("please enter product info");
		System.out.println("1. add product");
		System.out.println("2. get all product");
		System.out.println("3. get product by id");
		System.out.println("4. delete product");
		System.out.println("5. modify product");

		scan =new Scanner(System.in);
		int choice=scan.nextInt();
		switch(choice){
		case 1:
			System.out.println("enter product name");
			String name=scan.next();
			System.out.println("enter product price");
			float price=scan.nextFloat();
			int id=Product.generateProdId();
			Product prod=new Product(id,name,price);
			addProduct(prod);
			break;
		case 2:
			Map iterMap=getAllProducts();
			Iterator i= iterMap.entrySet().iterator();
			while(i.hasNext())
			{
				Map.Entry map=(Map.Entry)i.next();
				System.out.println(map.getKey()+" val : "+map.getValue());
			}
			break;
		case 3:
			System.out.println("pls enter the id to search ");
			int searchId=scan.nextInt();
			Product pro=getById(searchId);
			System.out.println("ur product is :: "+pro);
			break;
		case 4:
			break;
		case 5:
			Set all_keys=getAllProdId();
			System.out.println("pls choose one key to modify the product "+all_keys);
			int pid=scan.nextInt();
			Product p1=modifyProduct(pid);
			System.out.println(p1);
			break;
		default:
			break;
		
		}
	}
	private static Map getAllProducts() {
		
		return  prodMap;
	}
	private static void addProduct(Product prod) {
		// TODO Auto-generated method stub
		//db logic
		prodMap.put(prod.getpId(),prod);
		System.out.println(prod);
		System.out.println("map contains "+prodMap.size()+" contents"+prod);
		
	}
	public static Product getById(int searchId){
		Product p=(Product)prodMap.get(searchId);
		return p;
	}

	public static Set getAllProdId(){
		Set keys=prodMap.keySet();
		return keys;
	}
	public static Product modifyProduct(int prodId){
		Product p=(Product) prodMap.get(prodId);
		p.setPrice(23456.78f);
		prodMap.put(p.getpId(), p);
		System.out.println(prodMap);
		return p;
	}
}

class Product{
	
	private int pId;
	private String pName;
	private float price;
	
	public Product() {
		// TODO Auto-generated constructor stub
	}

	public static int generateProdId(){
		return (int)((Math.random()*10000)/2);
	}
	/**
	 * @return the pId
	 */
	public int getpId() {
		return pId;
	}

	/**
	 * @param pId the pId to set
	 */
	public void setpId(int pId) {
		this.pId = pId;
	}

	/**
	 * @return the pName
	 */
	public String getpName() {
		return pName;
	}

	/**
	 * @param pName the pName to set
	 */
	public void setpName(String pName) {
		this.pName = pName;
	}

	/**
	 * @return the price
	 */
	public float getPrice() {
		return price;
	}

	/**
	 * @param price the price to set
	 */
	public void setPrice(float price) {
		this.price = price;
	}

	public Product(int pId, String pName, float price) {
		super();
		this.pId = pId;
		this.pName = pName;
		this.price = price;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Product [pId=" + pId + ", pName=" + pName + ", price=" + price + "]";
	}
	
}
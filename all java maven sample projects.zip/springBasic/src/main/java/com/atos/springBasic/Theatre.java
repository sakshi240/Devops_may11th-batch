package com.atos.springBasic;

import org.springframework.stereotype.Component;

@Component("th")
public class Theatre {

	public Theatre() {
System.out.println("obj created");
	}
}

package com.atos.springBasic;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext ctx=new ClassPathXmlApplicationContext("spring.xml");
    	/*Theatre th1=(Theatre)ctx.getBean("th");
    	System.out.println(th1);*/
    }
}

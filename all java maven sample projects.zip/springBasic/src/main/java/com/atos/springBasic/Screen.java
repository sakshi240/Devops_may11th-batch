package com.atos.springBasic;

import org.springframework.stereotype.Component;

@Component
public class Screen {

	public Screen() {
		System.out.println("screen created");
	}
}

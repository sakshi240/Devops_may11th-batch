package com.pms;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CartController {

	@RequestMapping("data")
	public String getData(){
		return "this is a string msg";
	}
	
	@RequestMapping("htmlData")
	public String getHtmlData(){
		return "<h1>this is a string msg<h1>";
	}
	
	@RequestMapping("cart")
	public Cart getCartData(){
		
		Cart c=new Cart(1001,"this is obj1 ", 45);
		return c;//jackson data bind - http converters
	}
	
	@RequestMapping("login/{un}/{pass}")
	public String login(@PathVariable("un") String name,@PathVariable("pass") String pass){
		
		return "name : "+name+" pass : "+pass;
	}
	@RequestMapping(value="cart",method=RequestMethod.POST)
	public int getCartObj(@RequestBody Cart cart){
		System.out.println(cart);
		return cart.getCartId();//jackson data bind - http converters
	}
	
	
}









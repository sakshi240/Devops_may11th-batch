package com.pms;

public class Cart {

	private int cartId;
	private String descr;
	private int qty;
	
	public Cart() {
		// TODO Auto-generated constructor stub
	}

	public int getCartId() {
		return cartId;
	}

	public void setCartId(int cartId) {
		this.cartId = cartId;
	}

	public String getDescr() {
		return descr;
	}

	public void setDescr(String descr) {
		this.descr = descr;
	}

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	@Override
	public String toString() {
		return "Cart [cartId=" + cartId + ", descr=" + descr + ", qty=" + qty + "]";
	}

	public Cart(int cartId, String descr, int qty) {
		super();
		this.cartId = cartId;
		this.descr = descr;
		this.qty = qty;
	}
	
	
}

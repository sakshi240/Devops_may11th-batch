package com.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.Employee;

/**
 * Servlet implementation class EmpController
 */
@WebServlet("*.do")
public class EmpController extends HttpServlet {

	ArrayList<Employee> empList=null;
	
	public void init() throws ServletException {
		empList=new ArrayList<>();
		empList.add(new Employee("aaa","chn",900));
		empList.add(new Employee("bbb","mum",901));
		empList.add(new Employee("ccc","bglr",902));
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String s=req.getServletPath();
		String path=null;
		switch(s){
		
		case "/retrieve.do":
			req.setAttribute("empData",retrieveAll());
			path="emplist.jsp";
			break;
			
		default:
			break;
		}
		req.getRequestDispatcher(path).forward(req, resp);
		
	}

	private ArrayList<Employee> retrieveAll() {
		return empList;
		
	}

}
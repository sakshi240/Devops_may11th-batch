package com.atos.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class displayViewServlet
 */
@WebServlet("/display")
public class displayViewServlet extends HttpServlet {
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	System.out.println("in get");
	doPost(req, resp);
}

PrintWriter out=null;

@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
	out=resp.getWriter();
	String title="my page";
	out.println("<html> <head><title>"+title.toUpperCase()+"</title></head>");
	out.println("<body>");
	out.print("<h1>hi hello</h1>");
	out.println("</body></html>");
	
//doGet(req, resp);
	
	
}
	
}
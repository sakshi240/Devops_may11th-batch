package com.atos.servlet;

public class Product {

	private String prodName;
	private float price;
	private int qty;
	
	public Product() {
		// TODO Auto-generated constructor stub
	}

	public String getProdName() {
		return prodName;
	}

	public void setProdName(String prodName) {
		this.prodName = prodName;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	@Override
	public String toString() {
		return "Product [prodName=" + prodName + ", price=" + price + ", qty=" + qty + "]";
	}

	public Product(String prodName, float price, int qty) {
		
		this.prodName = prodName;
		this.price = price;
		this.qty = qty;
	}
	
}

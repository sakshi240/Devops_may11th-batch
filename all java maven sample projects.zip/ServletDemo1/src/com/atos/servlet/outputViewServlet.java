package com.atos.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class outputViewServlet
 */
@WebServlet("/output")
public class outputViewServlet extends HttpServlet {
	int count=1;
	PrintWriter out=null;
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
	out=resp.getWriter();
	resp.setHeader("refresh","3");
	resp.setContentType("text/plain");
	out.println("<html><body>");
	String m=(String)req.getAttribute("op");
	++count;
	out.println("view on the page is "+count);
		out.println("<h1>"+m+"</h1></body></html>");
	}

}
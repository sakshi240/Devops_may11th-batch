package com.atos.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CheckController
 */
@WebServlet("/chk.cdo")
public class CheckController extends HttpServlet {

@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

	RequestDispatcher disp=null;
	int num=Integer.parseInt(req.getParameter("numb"));
	String msg=null;
	
	if(num>0){
	msg="numb is positive";	
	}
	else{
		msg="numb is negative";
	}
	
	disp=req.getRequestDispatcher("output");
	req.setAttribute("op", msg);///map // this data is only for page u forward
	disp.forward(req, resp);
}

}